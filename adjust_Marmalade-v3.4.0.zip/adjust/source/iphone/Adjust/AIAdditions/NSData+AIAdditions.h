//
//  NSData+AIAdditions.h
//  Adjust
//
//  Created by Christian Wellenbrock on 01.10.12.
//  Copyright (c) 2012-2014 adjust GmbH. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface NSData(AIAdditions)

- (NSString *)aiEncodeBase64;

@end
