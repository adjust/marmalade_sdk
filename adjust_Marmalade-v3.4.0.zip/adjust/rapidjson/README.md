rapidjson
=========

Rapidjson wrapper for Marmalade (subproject)

[Rapidjson](https://code.google.com/p/rapidjson/) is fast JSON parser and generator.

You can read through [documentation](https://code.google.com/p/rapidjson/wiki/UserGuide) and check the samples.

Include the subproject rapidjson into your project and you are ready to go. :)
