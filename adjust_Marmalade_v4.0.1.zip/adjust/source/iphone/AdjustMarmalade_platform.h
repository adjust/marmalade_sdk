//
//  AdjustMarmalade_platform.h
//  AdjustMarmalade_iphone
//
//  Created by Uglješa Erceg on 06/10/15.
//
//

#import <Adjust/Adjust.h>

@interface AdjustMarmalade_platform : NSObject<AdjustDelegate>

@end